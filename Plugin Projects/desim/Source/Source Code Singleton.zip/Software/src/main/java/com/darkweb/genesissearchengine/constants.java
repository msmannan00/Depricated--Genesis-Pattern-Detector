package com.darkweb.genesissearchengine;

public class constants
{
    public static String backendUrl = "https://boogle.store";
    public static String backendUrlHost = "boogle.store";
    public static String frontEndUrlHost = "genesis.store";
    public static String allowedHost = ".onion";
}
