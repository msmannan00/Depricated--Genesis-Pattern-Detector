package com.darkweb.genesissearchengine;

public class status
{
    public static boolean hasApplicationLoaded = false;
    public static String currentURL = "http://boogle.store/";
    public static boolean isPlayStoreInstalled = false;
    public static int port = 9150;
    public static boolean isTorInitialized = false;
}
